import paho.mqtt.client as mqtt
import time

# Hàm callback được gọi khi client kết nối đến broker
def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print("Kết nối thành công đến MQTT Broker!")
    else:
        print(f"Kết nối thất bại với mã lỗi: {rc}")

def main():
    # 1. Khởi tạo một MQTT Client
    client = mqtt.Client()
    
    # Đăng ký hàm callback xử lý sự kiện kết nối
    client.on_connect = on_connect
    
    # 2. Thiết lập kết nối đến địa chỉ 127.0.0.1 ở cổng 1883
    broker_host = "127.0.0.1"
    broker_port = 1883
    
    print(f"Đang kết nối đến MQTT Broker tại {broker_host}:{broker_port}...")
    client.connect(broker_host, broker_port, keepalive=60)
    
    # Bắt đầu vòng lặp mạng nền để xử lý phản hồi từ broker
    client.loop_start()
    
    # 3. Chờ đợi trong giây lát để kiểm tra trạng thái kết nối thành công
    time.sleep(2)
    
    # Dừng vòng lặp và ngắt kết nối
    client.loop_stop()
    client.disconnect()

if __name__ == "__main__":
    main()