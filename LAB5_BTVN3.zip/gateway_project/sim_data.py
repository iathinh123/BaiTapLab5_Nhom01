import paho.mqtt.client as mqtt
import time
import json
import random

# Cấu hình kết nối tới Broker cục bộ trên máy Mac (localhost)
BROKER = "localhost"
PORT = 1883
TOPIC = "gateway/system/metrics"

client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)

try:
    client.connect(BROKER, PORT, 60)
    print("Đã kết nối thành công tới Mosquitto Broker!")
except Exception as e:
    print(f"Không thể kết nối broker: {e}")
    exit(1)

client.loop_start()

try:
    while True:
        # Giả lập thông số CPU và RAM ngẫu nhiên từ 10% đến 90%
        cpu_val = round(random.uniform(10.0, 90.0), 2)
        ram_val = round(random.uniform(30.0, 80.0), 2)

        # Đóng gói thành chuỗi JSON y hệt Bài 4
        payload = json.dumps({
            "cpu_usage": cpu_val,
            "ram_usage": ram_val
        })

        # Publish lên topic
        client.publish(TOPIC, payload)
        print(f"Đã gửi: {payload}")

        time.sleep(5) # Gửi định kỳ mỗi 5 giây

except KeyboardInterrupt:
    print("Đang dừng chương trình...")
    client.loop_stop()
    client.disconnect()