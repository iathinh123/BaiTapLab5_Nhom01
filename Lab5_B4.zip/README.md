# Bài 4: Gateway Publish dữ liệu phần cứng định kỳ (MQTT)

Script `bai4.py` đọc mức sử dụng CPU và RAM của máy (Gateway) bằng `psutil`, đóng gói thành JSON và publish lên Mosquitto Broker mỗi 5 giây.

- Broker: `127.0.0.1:1883`
- Topic: `gateway/system/metrics`
- Payload mẫu: `{"cpu": 15.2, "ram": 46.3}`

## Yêu cầu

- Python 3, Eclipse Mosquitto (service đang chạy)
- Thư viện: `psutil`, `paho-mqtt`

## Cài đặt

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

## Chạy

Terminal 1 - Subscriber:

```powershell
& "C:\Program Files\mosquitto\mosquitto_sub.exe" -h 127.0.0.1 -p 1883 -t gateway/system/metrics -v
```

Terminal 2 - Publisher:

```powershell
.\.venv\Scripts\python.exe bai4.py
```

Nhấn `Ctrl+C` để dừng.
