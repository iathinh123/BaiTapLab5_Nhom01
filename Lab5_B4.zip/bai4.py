"""Bai 4: Gateway publish CPU/RAM metrics to a local MQTT broker."""
import json
import sys
import time

import psutil
import paho.mqtt.client as mqtt

BROKER = "127.0.0.1"
PORT = 1883
TOPIC = "gateway/system/metrics"
INTERVAL = 5  # giay


def main():
    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
    try:
        client.connect(BROKER, PORT, 60)
    except OSError as e:
        print(f"Loi ket noi MQTT Broker {BROKER}:{PORT}: {e}")
        sys.exit(1)
    client.loop_start()
    print(f"Da ket noi MQTT Broker {BROKER}:{PORT}")
    try:
        next_run = time.monotonic()
        while True:
            # cpu_percent(interval=1) mat 1 giay, da nam trong chu ky 5 giay
            cpu = psutil.cpu_percent(interval=1)
            ram = psutil.virtual_memory().percent
            payload = json.dumps({"cpu": cpu, "ram": ram})
            result = client.publish(TOPIC, payload)
            if result.rc != mqtt.MQTT_ERR_SUCCESS:
                print("Loi publish:", mqtt.error_string(result.rc))
            else:
                result.wait_for_publish(timeout=3)
                print("Da gui:", payload)
            next_run += INTERVAL
            time.sleep(max(0, next_run - time.monotonic()))
    except KeyboardInterrupt:
        print("Da dung chuong trinh")
    finally:
        client.loop_stop()
        client.disconnect()


if __name__ == "__main__":
    main()
